﻿using System;
using System.Collections.Generic;
using System.Management;
using System.Net.NetworkInformation;
using System.Text;
using System.Windows;
using System.Windows.Input;
using System.Runtime.InteropServices;



namespace RikorTest
{
    /// <summary>
    /// Логика взаимодействия для Main.xaml
    /// </summary>
    public partial class Main : Window
    {
        private object pressedKeys;

        public Main()
        {
            InitializeComponent();
            this.PreviewKeyDown += Window_PreviewKeyDown;
            this.PreviewKeyUp += Window_PreviewKeyUp;
        
        }

        private void CheckAudioButton_Click(object sender, RoutedEventArgs e)
        {
            string message = IsAudioEnabled() ? "Аудиосистема работает." : "Нет звука в аудиосистеме.";
            MessageBox.Show(message, "Результат проверки", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private bool IsAudioEnabled()
        {
            // Пытаемся прикрепиться к первому устройству вывода звука
            try
            {
                var waveOut = new NAudio.Wave.WaveOut();
                return true; // Если устройство успешно создано, звук включен
            }
            catch
            {
                return false; // Ошибка при создании устройства
            }
        }

        private void Window_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            //Обработка нажатия клавиши
            MessageBox.Show($"Нажата клавиша: {e.Key}");
        }

        private void Window_PreviewKeyUp(object sender, KeyEventArgs e)
        {
            //Обработка отпускания клавиши (по желанию)
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            usbDeviceListBox.Items.Clear();
            try
            {
                List<string> usbDevices = GetUsbDevices();
                foreach (string device in usbDevices)
                {
                    usbDeviceListBox.Items.Add(device);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Произошла ошибка: {ex.Message}");
            }
        }

        private List<string> GetUsbDevices()
        {
            List<string> devices = new List<string>();
            try
            {
                using (ManagementObjectSearcher searcher = new ManagementObjectSearcher("SELECT * FROM Win32_PnPEntity WHERE DeviceID LIKE '%USB%'"))
                {
                    foreach (ManagementObject obj in searcher.Get())
                    {
                        string deviceID = obj["DeviceID"]?.ToString();
                        string name = obj["Name"]?.ToString();
                        string description = obj["Description"]?.ToString();

                        if (!string.IsNullOrEmpty(deviceID)) //Проверка на наличие DeviceID
                        {
                            devices.Add($"{name ?? "N/A"} ({description ?? "N/A"}) - {deviceID}");
                        }
                    }
                }
            }
            catch (ManagementException ex)
            {
                //Обработка исключений WMI
                MessageBox.Show($"Ошибка WMI: {ex.Message}");
            }
            catch (Exception ex)
            {
                //Обработка других исключений
                MessageBox.Show($"Общая ошибка: {ex.Message}");
            }
            return devices;
        }

        private void Button_Click1(object sender, RoutedEventArgs e)
        {
            osInfoTextBox.Text = GetOsInfo();
        }

        private string GetOsInfo()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine($"Операционная система: {Environment.OSVersion}");
            sb.AppendLine($"Имя платформы: {Environment.OSVersion.Platform}");
            sb.AppendLine($"Версия: {Environment.OSVersion.Version}");
            sb.AppendLine($"Сервисный пакет: {Environment.OSVersion.ServicePack}");
            sb.AppendLine($"Имя компьютера: {Environment.MachineName}");
            sb.AppendLine($"Пользователь: {Environment.UserName}");
            sb.AppendLine($"Текущий каталог: {Environment.CurrentDirectory}");
            sb.AppendLine($"Система каталогов: {Environment.SystemDirectory}");
            sb.AppendLine($"Временный каталог: {Environment.GetEnvironmentVariable("TEMP")}");

            //Получение информации о процессоре (более сложная часть)
            try
            {
                string processorInfo = GetProcessorInfo();
                sb.AppendLine($"Процессор: {processorInfo}");
            }
            catch (Exception ex)
            {
                sb.AppendLine($"Ошибка при получении информации о процессоре: {ex.Message}");
            }


            return sb.ToString();
        }


        //Функция для получения информации о процессоре (использует WMI)
        private string GetProcessorInfo()
        {
            using (ManagementObjectSearcher searcher = new ManagementObjectSearcher("SELECT * FROM Win32_Processor"))
            {
                foreach (ManagementObject obj in searcher.Get())
                {
                    return obj["Name"]?.ToString();
                }
            }
            return "Информация о процессоре недоступна";
        }

        private void Button_Click2(object sender, RoutedEventArgs e)
        {
            bool internetAvailable = CheckInternetConnection();
            resultTextBlock.Text = internetAvailable ? "Подключение к интернету есть" : "Подключение к интернету отсутствует";
        }

        private bool CheckInternetConnection()
        {
            try
            {
                using (var ping = new Ping())
                {
                    //Замените на любой доступный хост (например, Google)
                    string host = "google.com";
                    PingReply reply = ping.Send(host, 1000); //Таймаут 1 секунда
                    return reply != null && reply.Status == IPStatus.Success;
                }
            }
            catch (Exception ex)
            {
                //Обработка ошибок (например, отсутствие сетевого подключения)
                MessageBox.Show($"Ошибка: {ex.Message}");
                return false;
            }
        }
    }
    }
   
    
    

