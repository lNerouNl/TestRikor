﻿namespace NAudio
{
    internal class Wave
    {
        internal class WaveOut
        {
            public WaveOut()
            {
            }
        }
    }
}