﻿

using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System;

namespace RikorTest
{
   
    public partial class MainWindow : Window
    {
        private const string ConnectionString = "Server=DESKTOP-LURM5ET;Database=TestRikor;Trusted_Connection=True;";


        public MainWindow()
        {
            InitializeComponent();
        }



        private void LogIn_Click_1(object sender, RoutedEventArgs e)
        {
            string username = loginBox.Text;
            string password = PasswordContainer.Password;

            if (IsValidUser(username, password))
            {
                MessageBox.Show("Авторизация успешна!", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                // Создание экземпляра нового окна
                Main MainWindow = new Main();
                MainWindow.Show();
                // Закрытие текущего окна
                this.Close();
            }
            else
            {
                MessageBox.Show("Неправильные данные или пустое поле", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private bool IsValidUser(string username, string password)
        {
            // Здесь можно добавить логику проверки пользователя.
            // Для примера, используем фиксированные значения.
            return username == "12" && password == "12";
        }


    
        
    }
}
